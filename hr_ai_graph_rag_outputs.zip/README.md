# 安久銀行 HR AI 智能助理 - Colab Technical Demo

## 技術內容
- 使用者上傳模擬員工內規 DOCX：補足企業內部規則層
- Policy-aware Hierarchical Chunking：Document-level / Article-level / Semantic sub-chunk
- FAQ Chunk：預設不使用 Golden Dataset 進知識庫；若設 USE_GOLDEN_AS_FAQ_CHUNKS=true 才做實驗性 FAQ chunk
- Hybrid Retrieval：Vector + BM25 + keyword + metadata priority
- Offline Artifacts：讀取 concept_nodes / risk_policy / query_patterns / rewrite_rules / relation_schema / graph_relation_candidates JSON
- Knowledge Graph / Graph RAG：建立 law / internal_policy / concept 節點與 approved graph relations
- LangGraph Workflow：Runtime Local LLM Classification -> Retrieval Orchestrator -> Deterministic Guardrails -> Answer / Disclaimer / Clarify / Escalate
- HuggingFace Local LLM：Colab GPU 載入 Instruct model，不需 OpenAI API key；負責分類 signal 與 grounded answer generation
- 使用者上傳 Golden Dataset JSON Evaluation：category, route, retrieval, source type, citation, faithfulness, latency

## 主要輸出
- articles.json
- chunks_3layer_faq.json / csv
- kg_nodes.csv / kg_edges.csv / hr_knowledge_graph.gexf
- golden_dataset.csv
- evaluation_detail.csv
- evaluation_summary.csv
- demo_results.json
- feedback_log.csv